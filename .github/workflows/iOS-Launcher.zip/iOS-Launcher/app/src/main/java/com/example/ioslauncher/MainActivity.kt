package com.example.ioslauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt
import kotlin.random.Random

data class AppItem(val pkg: String, val label: String, val icon: ImageBitmap)
data class Wall(val a: Color, val b: Color, val c: Color)

val walls = listOf(
    Wall(Color(0xFF0F2027), Color(0xFF2C7A7B), Color(0xFF8E54E9)),
    Wall(Color(0xFF2B1055), Color(0xFFFF6B6B), Color(0xFFFFC371)),
    Wall(Color(0xFF021B79), Color(0xFF0575E6), Color(0xFF00F2FE)),
    Wall(Color(0xFF0B3D2E), Color(0xFF1FA67A), Color(0xFFB8F2C9)),
    Wall(Color(0xFF0A0A0C), Color(0xFF2B2B33), Color(0xFF55556A)),
    Wall(Color(0xFF3A0CA3), Color(0xFFF72585), Color(0xFFFFB4D1)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContent { Launcher() }
    }
}

fun loadApps(c: Context): List<AppItem> {
    val pm = c.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != c.packageName }
        .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm).toBitmap(144, 144).asImageBitmap()) }
        .distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
}

fun dockPkgs(c: Context): List<String> {
    val pm = c.packageManager
    return listOf(
        Intent(Intent.ACTION_DIAL), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://")), Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    ).mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
        .filter { it != "android" }.distinct()
}

fun Modifier.glass(r: Dp, a: Float = .24f): Modifier {
    val s = RoundedCornerShape(r)
    return clip(s).background(Color.White.copy(a)).border(1.dp, Color.White.copy(.3f), s)
}

@Composable
fun jiggle(on: Boolean): State<Float> {
    if (!on) return remember { mutableFloatStateOf(0f) }
    return rememberInfiniteTransition(label = "j").animateFloat(
        -2.2f, 2.2f, infiniteRepeatable(tween(120, easing = LinearEasing), RepeatMode.Reverse), label = "r"
    )
}

@Composable
fun Wallpaper(w: Wall, shift: () -> Float) {
    val grain = remember { val r = Random(7); List(2200) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat()) } }
    Canvas(Modifier.fillMaxSize().graphicsLayer { translationX = shift(); scaleX = 1.15f; scaleY = 1.05f }) {
        drawRect(Brush.verticalGradient(listOf(w.a, w.b)))
        val r = size.width * .95f
        val p1 = Offset(size.width * .2f, size.height * .8f)
        val p2 = Offset(size.width * .9f, size.height * .15f)
        drawCircle(Brush.radialGradient(listOf(w.c.copy(.85f), Color.Transparent), p1, r), r, p1)
        drawCircle(Brush.radialGradient(listOf(w.c.copy(.45f), Color.Transparent), p2, r * .7f), r * .7f, p2)
        grain.forEach { (x, y, a) -> drawCircle(Color.White.copy(.02f + a * .05f), 1.2f, Offset(x * size.width, y * size.height)) }
    }
}

@Composable
fun Clock() {
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val t = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now))
    val d = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now)).replaceFirstChar { it.uppercase() }
    Column(
        Modifier.fillMaxWidth().glass(26.dp, .2f).padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Text(d, style = TextStyle(color = Color.White.copy(.85f), fontSize = 14.sp, fontWeight = FontWeight.Medium))
        Text(t, style = TextStyle(color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Light))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppIcon(
    a: AppItem, label: Boolean, edit: Boolean, jig: State<Float>, idx: Int,
    onOpen: (Offset) -> Unit, onLong: () -> Unit, onRemove: () -> Unit
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val press by animateFloatAsState(if (pressed) .84f else 1f, spring(.45f, 500f), label = "p")
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay((idx % 20) * 22L); shown = true }
    val pop by animateFloatAsState(if (shown) 1f else .3f, spring(.55f, 300f), label = "s")
    var c by remember { mutableStateOf(Offset.Zero) }
    val sq = RoundedCornerShape(23)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .graphicsLayer {
                val s = press * pop; scaleX = s; scaleY = s
                rotationZ = if (edit) jig.value * (if (idx % 2 == 0) 1f else -1f) else 0f
                alpha = pop.coerceIn(0f, 1f)
            }
            .combinedClickable(src, null, onClick = { if (!edit) onOpen(c) }, onLongClick = onLong)
    ) {
        Box {
            Box(
                Modifier.size(60.dp)
                    .onGloballyPositioned { c = it.positionInRoot() + Offset(it.size.width / 2f, it.size.height / 2f) }
                    .shadow(6.dp, sq).clip(sq).background(Color(0xFF1C1C1E))
                    .drawWithContent {
                        drawContent()
                        drawRect(Brush.verticalGradient(listOf(Color.White.copy(.16f), Color.Transparent), endY = size.height * .55f))
                    }
            ) { Image(a.icon, null, Modifier.fillMaxSize().graphicsLayer { scaleX = 1.12f; scaleY = 1.12f }) }
            if (edit) Box(
                Modifier.offset((-6).dp, (-6).dp).size(22.dp).clip(CircleShape)
                    .background(Color(0xFF8E8E93)).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) { Text("−", style = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)) }
        }
        if (label) Text(
            a.label, Modifier.width(72.dp).padding(top = 5.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            style = TextStyle(color = Color.White, fontSize = 11.sp, shadow = Shadow(Color.Black.copy(.45f), Offset(0f, 1.5f), 4f))
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Launcher() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("ios", Context.MODE_PRIVATE) }
    val apps by produceState(emptyList<AppItem>()) { value = withContext(Dispatchers.Default) { loadApps(ctx) } }
    var hidden by remember { mutableStateOf(prefs.getStringSet("hidden", emptySet())!!.toSet()) }
    var wall by remember { mutableIntStateOf(prefs.getInt("wall", 0).coerceIn(0, walls.lastIndex)) }
    var edit by remember { mutableStateOf(false) }
    var opening by remember { mutableStateOf<Pair<AppItem, Offset>?>(null) }
    val sc = remember { Animatable(1f) }
    val al = remember { Animatable(1f) }
    val dockIds = remember { dockPkgs(ctx) }
    val dock = dockIds.mapNotNull { id -> apps.find { it.pkg == id } }
    val home = apps.filter { it.pkg !in hidden && it.pkg !in dockIds }
    val pages = listOf(home.take(12)) + home.drop(12).chunked(20)
    val pager = rememberPagerState { pages.size }
    val jig = jiggle(edit)
    val sq = RoundedCornerShape(23)
    BackHandler(edit) { edit = false }
    fun open(a: AppItem, o: Offset) { if (!edit) opening = a to o }

    LaunchedEffect(opening) {
        val o = opening ?: return@LaunchedEffect
        sc.snapTo(1f); al.snapTo(1f)
        val j = launch { sc.animateTo(22f, tween(420, easing = FastOutSlowInEasing)) }
        delay(160)
        ctx.packageManager.getLaunchIntentForPackage(o.first.pkg)?.let { ctx.startActivity(it) }
        launch { al.animateTo(0f, tween(300)) }
        j.join()
        opening = null
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Crossfade(wall, label = "wall") { i ->
            Wallpaper(walls[i]) { -(pager.currentPage + pager.currentPageOffsetFraction) * 40f }
        }
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            HorizontalPager(
                pager,
                Modifier.weight(1f).pointerInput(Unit) { detectTapGestures(onLongPress = { edit = true }, onTap = { edit = false }) }
            ) { p ->
                Column(
                    Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (p == 0) Clock()
                    pages.getOrElse(p) { emptyList() }.chunked(4).forEachIndexed { r, row ->
                        Row(Modifier.fillMaxWidth()) {
                            row.forEachIndexed { i, a ->
                                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                    AppIcon(a, true, edit, jig, r * 4 + i, { o -> open(a, o) }, { edit = true }) {
                                        hidden = hidden + a.pkg
                                        prefs.edit().putStringSet("hidden", hidden).apply()
                                    }
                                }
                            }
                            repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), Arrangement.Center) {
                repeat(pages.size) { i ->
                    val d by animateFloatAsState(if (pager.currentPage == i) 1f else .4f, label = "d")
                    Box(Modifier.padding(3.dp).size(7.dp).clip(CircleShape).background(Color.White.copy(d)))
                }
            }
            AnimatedVisibility(edit, enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 14.dp).glass(26.dp).padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(Modifier.horizontalScroll(rememberScrollState()), Arrangement.spacedBy(12.dp)) {
                        walls.forEachIndexed { i, w ->
                            val sel = i == wall
                            Box(
                                Modifier.size(44.dp).clip(CircleShape)
                                    .background(Brush.linearGradient(listOf(w.a, w.b, w.c)))
                                    .border(if (sel) 3.dp else 1.dp, Color.White.copy(if (sel) 1f else .4f), CircleShape)
                                    .clickable { wall = i; prefs.edit().putInt("wall", i).apply() }
                            )
                        }
                    }
                    Row {
                        TextButton({ hidden = emptySet(); prefs.edit().remove("hidden").apply() }) { Text("Restaurar apps", color = Color.White) }
                        TextButton({ edit = false }) { Text("Listo", color = Color.White, fontWeight = FontWeight.Bold) }
                    }
                }
            }
            Row(
                Modifier.padding(horizontal = 14.dp, vertical = 10.dp).fillMaxWidth().glass(34.dp).padding(14.dp),
                Arrangement.SpaceEvenly
            ) {
                dock.forEachIndexed { i, a -> AppIcon(a, false, false, jig, i, { o -> open(a, o) }, {}, {}) }
            }
        }
        opening?.let { (a, o) ->
            Image(
                a.icon, null,
                Modifier.offset { IntOffset((o.x - 30.dp.toPx()).roundToInt(), (o.y - 30.dp.toPx()).roundToInt()) }
                    .size(60.dp)
                    .graphicsLayer { scaleX = sc.value; scaleY = sc.value; alpha = al.value }
                    .clip(sq)
            )
        }
    }
}
