# iLauncher
Launcher Android estilo iOS (Kotlin + Compose): iconos squircle, dock de cristal, páginas con parallax, modo edición con jiggle, fondos con textura.

1. Sube esta carpeta a un repo de GitHub (rama main).
2. Pestaña Actions -> "Build APK" -> espera al check verde.
3. Descarga el artifact `iLauncher-apk`, instala el APK y pulsa Inicio -> elige iLauncher.
