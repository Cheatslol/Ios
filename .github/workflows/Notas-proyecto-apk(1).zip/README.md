# Notas

App de notas sin permisos (sin internet) con bóveda cifrada en 2 capas:

1. AES-256-GCM con llave derivada de tu contraseña (PBKDF2-HMAC-SHA256, 600.000 vueltas).
2. AES-256-GCM con una llave del Android Keystore (no sale del teléfono).

La contraseña no se guarda en ningún lado. La creas la primera vez que abres la app.
Si la olvidas, las notas no se pueden recuperar.

Compilar: sube todo el proyecto a GitHub (manteniendo las carpetas). En la pestaña Actions
se ejecuta "Build APK" y al terminar descargas `Notas-APK` (contiene `app-debug.apk`).
