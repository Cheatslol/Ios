package com.boveda.notas;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;

public class MainActivity extends Activity {

    private WebView web;
    private Vault vault;

    private SharedPreferences lockPrefs() {
        return getSharedPreferences("lock", Context.MODE_PRIVATE);
    }

    /** Puente entre la pantalla (HTML) y la bóveda cifrada. */
    public class Bridge {

        @JavascriptInterface
        public boolean hasVault() {
            return vault.exists();
        }

        @JavascriptInterface
        public boolean setup(String pass) {
            return vault.setup(pass);
        }

        /** Devuelve las notas o null si la contraseña es incorrecta o hay que esperar. */
        @JavascriptInterface
        public String unlock(String pass) {
            if (waitSeconds() > 0) return null;
            String result = vault.unlock(pass);
            SharedPreferences.Editor e = lockPrefs().edit();
            if (result == null) {
                int fails = lockPrefs().getInt("fails", 0) + 1;
                e.putInt("fails", fails);
                if (fails >= 5) {
                    long delay = Math.min(30000L << Math.min(fails - 5, 7), 3600000L);
                    e.putLong("until", System.currentTimeMillis() + delay);
                }
            } else {
                e.putInt("fails", 0).putLong("until", 0L);
            }
            e.apply();
            return result;
        }

        @JavascriptInterface
        public int waitSeconds() {
            long rem = lockPrefs().getLong("until", 0L) - System.currentTimeMillis();
            return rem > 0 ? (int) ((rem + 999) / 1000) : 0;
        }

        @JavascriptInterface
        public void save(String json) {
            vault.save(json);
        }

        @JavascriptInterface
        public void lock() {
            vault.lock();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Sin capturas de pantalla y sin vista previa en "recientes"
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);

        vault = new Vault(new File(getFilesDir(), "vault.bin"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#101722"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Android");

        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.goBack ? window.goBack() : false", value -> {
            if (!"true".equals(value)) {
                finish();
            }
        });
    }

    @Override
    protected void onPause() {
        web.evaluateJavascript("window.flush && window.flush()", null);
        super.onPause();
    }

    /** Al salir de la app, la bóveda se cierra y pide la contraseña otra vez. */
    @Override
    protected void onStop() {
        web.evaluateJavascript("window.lockNow && window.lockNow()", null);
        super.onStop();
    }
}
