package com.boveda.notas;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Bóveda cifrada en 2 capas:
 *  Capa 1: AES-256-GCM con una llave derivada de tu contraseña (PBKDF2-HMAC-SHA256, 600.000 vueltas).
 *  Capa 2: AES-256-GCM con una llave del Android Keystore (no se puede sacar del teléfono).
 * La contraseña nunca se guarda: solo existe en memoria mientras la bóveda está abierta.
 */
public class Vault {

    private static final String KS_ALIAS = "notas_vault_key_v1";
    private static final int ITERATIONS = 600000;
    private static final int SALT_LEN = 16;
    private static final int IV_LEN = 12;

    private final File file;
    private SecretKey key;   // llave de la capa 1, solo en memoria
    private byte[] salt;

    public Vault(File file) {
        this.file = file;
    }

    public boolean exists() {
        return file.exists();
    }

    public synchronized void lock() {
        key = null;
        if (salt != null) Arrays.fill(salt, (byte) 0);
        salt = null;
    }

    public synchronized boolean setup(String pass) {
        if (file.exists()) return false;
        try {
            byte[] s = new byte[SALT_LEN];
            new SecureRandom().nextBytes(s);
            salt = s;
            key = derive(pass, s);
            return write("[]");
        } catch (Exception e) {
            lock();
            return false;
        }
    }

    /** Devuelve las notas (JSON) o null si la contraseña es incorrecta. */
    public synchronized String unlock(String pass) {
        try {
            byte[] outer = Files.readAllBytes(file.toPath());
            byte[] blob = layer2Decrypt(outer);

            ByteBuffer b = ByteBuffer.wrap(blob);
            if (b.get() != 1) return null;
            byte[] s = new byte[SALT_LEN];
            b.get(s);
            byte[] iv = new byte[IV_LEN];
            b.get(iv);
            byte[] ct = new byte[b.remaining()];
            b.get(ct);

            SecretKey k = derive(pass, s);
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, k, new GCMParameterSpec(128, iv));
            byte[] plain = c.doFinal(ct); // falla si la contraseña es incorrecta

            key = k;
            salt = s;
            return new String(plain, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    public synchronized boolean save(String json) {
        if (key == null) return false;
        try {
            return write(json);
        } catch (Exception e) {
            return false;
        }
    }

    // ---------- internos ----------

    private boolean write(String json) throws Exception {
        byte[] iv = new byte[IV_LEN];
        new SecureRandom().nextBytes(iv);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
        byte[] ct = c.doFinal(json.getBytes(StandardCharsets.UTF_8));

        ByteBuffer b = ByteBuffer.allocate(1 + SALT_LEN + IV_LEN + ct.length);
        b.put((byte) 1).put(salt).put(iv).put(ct);

        byte[] outer = layer2Encrypt(b.array());

        File tmp = new File(file.getParentFile(), file.getName() + ".tmp");
        try (FileOutputStream out = new FileOutputStream(tmp)) {
            out.write(outer);
            out.getFD().sync();
        }
        return tmp.renameTo(file);
    }

    private static SecretKey derive(String pass, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pass.toCharArray(), salt, ITERATIONS, 256);
        try {
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return new SecretKeySpec(f.generateSecret(spec).getEncoded(), "AES");
        } finally {
            spec.clearPassword();
        }
    }

    private static SecretKey keystoreKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(KS_ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(KS_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(KS_ALIAS, null);
    }

    private static byte[] layer2Encrypt(byte[] data) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, keystoreKey());
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(data);
        ByteBuffer b = ByteBuffer.allocate(iv.length + ct.length);
        b.put(iv).put(ct);
        return b.array();
    }

    private static byte[] layer2Decrypt(byte[] data) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, keystoreKey(), new GCMParameterSpec(128, Arrays.copyOfRange(data, 0, IV_LEN)));
        return c.doFinal(data, IV_LEN, data.length - IV_LEN);
    }
}
