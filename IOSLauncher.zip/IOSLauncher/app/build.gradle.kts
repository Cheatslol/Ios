plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.ioslauncher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.ioslauncher"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.1"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.viewpager:viewpager:1.0.0")
}
