package com.example.ioslauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager

data class AppItem(val label: String, val pkg: String, val icon: Drawable)

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // Icono con esquinas redondeadas estilo iOS
    private fun iconView(app: AppItem, size: Int): ImageView = ImageView(this).apply {
        layoutParams = LinearLayout.LayoutParams(size, size)
        setImageDrawable(app.icon)
        setPadding(dp(4), dp(4), dp(4), dp(4))
        background = GradientDrawable().apply { setColor(Color.WHITE) }
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, v.width * 0.225f)
            }
        }
    }

    private fun open(app: AppItem) {
        packageManager.getLaunchIntentForPackage(app.pkg)?.let { startActivity(it) }
    }

    // Una página = cuadrícula de 4 columnas
    private fun gridPage(items: List<AppItem>) = GridView(this).apply {
        numColumns = 4
        verticalSpacing = dp(18)
        selector = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int) = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val app = items[p]
                return LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    addView(iconView(app, dp(60)))
                    addView(TextView(context).apply {
                        text = app.label
                        setTextColor(Color.WHITE)
                        textSize = 11f
                        maxLines = 1
                        gravity = Gravity.CENTER
                        setShadowLayer(4f, 0f, 1f, Color.BLACK)
                        setPadding(0, dp(4), 0, 0)
                    })
                    setOnClickListener { open(app) }
                }
            }
        }
    }

    private fun clockText(f24: String, f12: String, size: Float) = TextClock(this).apply {
        format24Hour = f24
        format12Hour = f12
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setShadowLayer(6f, 0f, 2f, Color.BLACK)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pm = packageManager

        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }

        // Dock: teléfono, mensajes, navegador, cámara (si no existen, primeras apps)
        val probes = listOf(
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:")),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val dockApps = mutableListOf<AppItem>()
        probes.forEach { i ->
            val p = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
            apps.firstOrNull { it.pkg == p }?.let { if (it !in dockApps) dockApps.add(it) }
        }
        if (dockApps.size < 4) {
            dockApps.addAll(apps.filter { it !in dockApps }.take(4 - dockApps.size))
        }
        val pages = apps.filter { it !in dockApps }.chunked(20)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(40), dp(8), dp(16))
        }

        // Reloj y fecha
        root.addView(clockText("HH:mm", "h:mm", 56f))
        root.addView(clockText("EEEE, d MMMM", "EEEE, d MMMM", 16f),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(16) })

        // Páginas deslizables
        val pager = ViewPager(this)
        pager.adapter = object : PagerAdapter() {
            override fun getCount() = pages.size
            override fun isViewFromObject(v: View, o: Any) = v === o
            override fun instantiateItem(c: ViewGroup, p: Int): Any {
                val v = gridPage(pages[p]); c.addView(v); return v
            }
            override fun destroyItem(c: ViewGroup, p: Int, o: Any) { c.removeView(o as View) }
        }
        root.addView(pager, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // Puntitos indicadores
        val dots = LinearLayout(this).apply { gravity = Gravity.CENTER }
        repeat(pages.size) {
            dots.addView(View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
                alpha = 0.4f
            }, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), dp(8), dp(4), dp(8)) })
        }
        fun paint(sel: Int) {
            for (i in 0 until dots.childCount) dots.getChildAt(i).alpha = if (i == sel) 1f else 0.4f
        }
        paint(0)
        pager.addOnPageChangeListener(object : ViewPager.SimpleOnPageChangeListener() {
            override fun onPageSelected(position: Int) = paint(position)
        })
        root.addView(dots)

        // Dock
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply { setColor(0x55FFFFFF); cornerRadius = dp(32).toFloat() }
        }
        dockApps.forEach { app ->
            dock.addView(LinearLayout(this).apply {
                gravity = Gravity.CENTER
                addView(iconView(app, dp(60)))
                setOnClickListener { open(app) }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(dock, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(8), dp(4), dp(8), 0) })

        setContentView(root)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { /* el launcher no se cierra */ }
}
